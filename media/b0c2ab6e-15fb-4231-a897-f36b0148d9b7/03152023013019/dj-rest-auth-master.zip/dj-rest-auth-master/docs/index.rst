.. dj-rest-auth documentation master file, created by
   sphinx-quickstart on Wed Oct  8 15:59:37 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to dj-rest-auth's documentation!
============================================


.. note:: dj-rest-auth version 1.0.0 now uses Django Simple JWT.


.. image:: https://circleci.com/gh/iMerica/dj-rest-auth.svg?style=svg
    :target: https://circleci.com/gh/iMerica/dj-rest-auth

Contents
--------

.. toctree::
   :maxdepth: 2

   Introduction <introduction>
   Installation <installation>
   API endpoints <api_endpoints>
   Configuration <configuration>
   Demo project <demo>
   FAQ <faq>
   Disclosure Policy <disclosure>
